#!/bin/bash


echo " This is inside /bash_scripting/script folder/directory"

exit 0


