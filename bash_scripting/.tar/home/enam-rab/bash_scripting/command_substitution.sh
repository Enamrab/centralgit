#!/bin/bash
#
#Command substitution script demo

msg=$(date +%H:%m:%S)

echo "Hi ${USER^} the current date and time is $msg."
echo "You are inside this date is: $(date)"
echo "--------------------------------------------------"

currentdir=$(pwd)
echo "I will now backup your home directory ${currentdir}!"
echo "You are running this script from ${currentdir}"
echo "Therefore I will save the backup in in $(pwd)"
echo "--------------------------------------------"
echo "                                             "

tar -cf $HOME_backup_archive_.tar /home/enam-rab/bash_scripting  2>/dev/null


echo "       "
echo "Backup completed successfully!"

exit 0

